/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exeptionhandling;

/**
 *
 * @author DELL
 */
public class titan extends character{

    public titan() {
        super(0, 45, 200);
    }

    @Override
    public boolean attack() {
        return Math.random()<= 0.40; //To change body of generated methods, choose Tools | Templates.
    }
    
}
