/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exeptionhandling;

/**
 *
 * @author DELL
 */
abstract class character {
    private int defense;
    private int attack;
    private int hp;
    public character(int defense, int attack, int hp){
        this.attack = attack;
        this.defense = defense;
        this.hp = hp;
    }
    public int getAttack(){
        return attack;
    }
    public int getDefense(){
        return defense;
    }
    public int getHP(){
        return this.hp;
    }
    public void setHP(int hp){
        this.hp=hp;
    }
    public abstract boolean attack();
    public void receiveDamage(int damage){
        if(damage>getDefense()){
            this.hp -= (damage-getDefense());
            if(getHP()<0) setHP(0);
        }
    }
    public void info(){
        System.out.println("=======Status=======");
        System.out.println("Role    : "+ getClass().getSimpleName());
        System.out.println("Hp      : "+ getHP());
        System.out.println("Attack  : "+ getAttack());
        System.out.println("Defense : "+ getDefense());
    }
    
}
