/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exeptionhandling;

/**
 *
 * @author DELL
 */
public class Healer extends character {

    public Healer() {
        super(10, 10, 70);
    }

    @Override
    public boolean attack() {
        return Math.random()<= 0.85; //To change body of generated methods, choose Tools | Templates.
    }
    public void heal(){
        setHP(getHP()+25);
        System.out.println("Healing ability used..........");
    }
}
