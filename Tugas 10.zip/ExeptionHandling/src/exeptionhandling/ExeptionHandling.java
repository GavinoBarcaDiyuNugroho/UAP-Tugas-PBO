/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exeptionhandling;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author DELL
 */
public class ExeptionHandling {
    public static final Scanner S = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("==============================");
        System.out.println("Selamat datang di game defend FILKOM");
        System.out.println("Silahkan masukkan nama player : ");
        String nama = S.nextLine();
        character player = inputpilihan();
        titan titan = new titan();
        System.out.println("Selamat datang " + nama +" :");
        player.info();
        System.out.println();
        
        String hasilgame = game(titan,player,nama);
        if(hasilgame.equalsIgnoreCase("Menang")) System.out.println("Menang");
        else if(hasilgame.equalsIgnoreCase("Kalah")) System.out.println("Kalah");
        else if(hasilgame.equalsIgnoreCase("Seri"))System.out.println("Pertandingan berakhir dengan seri.....");
        
        System.out.println("==============Player==============");
        player.info();
        System.out.println("==============Musuh==============");
        titan.info();
        System.out.println("==================================");

    }
    
    static character inputpilihan(){
        System.out.println("Silahkan pilih karakter yang anda inginkan : ");
        System.out.println("1. Magician");
        System.out.println("2. Healer");
        System.out.println("3. Warrior");
        try{
            int pilihan = Integer.parseInt(S.nextLine());
            if(pilihan<1||pilihan>3)
                throw new InputMismatchException();
                
            switch(pilihan){
                case 1 :
                    return new magician();
                case 2 :
                    return new Healer();
                default:
                    return new warrior();       
                }
        }catch (Exception e){
            if (e instanceof NumberFormatException){
                System.out.println("Tolong masukkan input dalam bentuk angka!");
            }
            else if(e instanceof InputMismatchException){
                System.out.println("Tolong masukkan input antara 1-3!");
            }
            return inputpilihan();
        }
        
    }
    static String game(titan titan, character hero, String nama){
        String hasil = "";
        for(int i = 1; ; i++){
            System.out.println("------------------- Turn ; " + i);
          if(i<10)
                System.out.println("=======================");
          else System.out.println("====================");
          if(i%2==0 && hero instanceof Healer){
              System.out.println(nama + "Menggunakan skill heal!");
          }
          if(hero.attack()){
              System.out.println(nama + "Berhasil Menyerang Titan!");
              titan.receiveDamage(hero.getAttack());
          }
          if(titan.attack()){
              System.out.println("Titan berhasil menyerang "+nama+"!");
              hero.receiveDamage(titan.getAttack());
          }
            System.out.println("Enemy HP :" +titan.getHP());
            System.out.println(nama+" HP" + hero.getHP());
            if(titan.getHP()==0 && hero.getHP()==0){
                return "seri";
            }
            else if(titan.getHP()==0)return "Menang";
            else if (hero.getHP()==0)return "Kalah";
          
        }
        
    }
    
}
