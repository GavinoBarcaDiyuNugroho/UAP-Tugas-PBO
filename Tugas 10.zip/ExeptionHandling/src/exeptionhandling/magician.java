/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exeptionhandling;

/**
 *
 * @author DELL
 */
public class magician extends character {

    public magician() {
        super(10,60,100);
    }
    @Override
    public boolean attack() {
        return Math.random()<= 0.35; //To change body of generated methods, choose Tools | Templates.
    }
    
}
