/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coba.bollean;

/**
 *
 * @author DELL
 */
public class CarRider {
    private String name, phone;
    private int age;
    public CarRider(String name, String phone, int age){
        this.name = name;
        this.age = age;
        this.phone = phone;
    }
    public String getName(){
        return name;
    }
    public int getAge(){
        return age;
    }
    public String getPhone(){
        return phone;
    }
    
    
    
}
