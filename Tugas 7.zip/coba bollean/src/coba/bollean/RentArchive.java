/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coba.bollean;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author DELL
 */
public class RentArchive {
    private ArrayList <CarRent> rentData=new ArrayList <CarRent>();
    public void rent(CarRider rider, Car car, int RentDur){
        if(car.isStatus()==true){
            rentData.add(new CarRent(rider, car, RentDur));
            System.out.println("MOBIL BERHASIL DISEWA");
            car.setStatus("false");
        }
        else System.out.println("MAAF, MOBIL SUDAH DISEWA");
        
    }
    public void info(){
        Iterator<CarRent> itr = rentData.iterator();
            System.out.println("-----------------------");
            System.out.println("INFORMASI PELANGGAN");
            System.out.println("-----------------------");
            while (itr.hasNext()) {
                CarRent carrent = itr.next();
                System.out.println("NAMA PEMINJAM  :   " + carrent.getRider().getName());
                System.out.println("TIPE MOBIL  :   " + carrent.getCar().getCartype());
                System.out.println("NO. POLISI  :   " + carrent.getCar().getpolNum());
                System.out.println("LAMA RENTAL :   " + carrent.getRentDur());
                System.out.println("-----------------------");
            }
    }
    
}
