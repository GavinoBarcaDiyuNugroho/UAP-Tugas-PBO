/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coba.bollean;

/**
 *
 * @author DELL
 */
public class Car {
    private String carType, polNum, merk;
    private boolean status;
    public Car(String carType, String polNum, String merk, boolean status){
        this.carType = carType;
        this.merk = merk;
        this.polNum = polNum;
        this.status = status;
    }
    public String getpolNum(){
        return polNum;
    }
    public String getMerk(){
        return merk;
    }
    public boolean isStatus(){
        return status;
    }
    public String getCartype(){
        return carType;
    }
    public void setStatus(String status){
        if("false".equals(status)){
            this.status = false;
        }
        else this.status = true;
    }
}
