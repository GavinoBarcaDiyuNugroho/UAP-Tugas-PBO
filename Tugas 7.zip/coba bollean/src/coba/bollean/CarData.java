/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coba.bollean;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author DELL
 */
public class CarData {
    public ArrayList <Car> carList=new ArrayList <Car>();
    public void addCar(String carType, String polNum, String merk){
        carList.add(new Car(carType, polNum, merk,true));
    }
    public void listOfCar(){
            Iterator<Car> itr = carList.iterator();
            System.out.println("-----------------------");
            System.out.println("DAFTAR MOBIL");
            System.out.println("-----------------------");
            while (itr.hasNext()) {
                Car car = itr.next();
                System.out.println("TIPE MOBIL  :   " + car.getCartype());
                System.out.println("NO. POLISI  :   " + car.getpolNum());
                System.out.println("MERK MOBIL  :   " + car.getMerk());
                System.out.println("-----------------------");
            }
    }
}
