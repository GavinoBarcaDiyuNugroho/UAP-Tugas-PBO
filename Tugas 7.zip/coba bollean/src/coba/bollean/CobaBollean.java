/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coba.bollean;

/**
 *
 * @author DELL
 */
public class CobaBollean {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CarRider ming = new CarRider("Lin Ming","08000000",19);
        CarRider youhan = new CarRider("Bei Youhan","08111111",20);
        CarRider ling = new CarRider("Ling'er","082222222",31);
        CarRider Gavino = new CarRider("Gavin","082139053919",20);
        
        
        CarData data = new CarData();
        data.addCar("SUV", "N 1111 AB", "HONDA");
        data.addCar("SPORT", "N 2222 AB", "SSC TUATARA");
        data.addCar("TRUCK", "N 3333 AB", "SUZUKI");
        data.addCar("SEDAN", "K 0570 AL", "TOYOTA");
        data.listOfCar();
        
        RentArchive arsip = new RentArchive();
        arsip.rent(ming, data.carList.get(1), 9);
        arsip.rent(youhan, data.carList.get(0), 3);
        arsip.rent(ling, data.carList.get(1), 1);
        arsip.rent(Gavino, data.carList.get(2), 4);
        arsip.info();
        
    }
    
}
