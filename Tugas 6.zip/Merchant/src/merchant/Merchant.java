/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package merchant;

/**
 *
 * @author DELL
 */
public class Merchant {
    private String namaMerchant;
    private String namaProduk;
    private double hargaMakanan = 0;
    Merchant(String namaMerchant, String namaProduk, Double hargaMakanan){
        this.namaMerchant = namaMerchant;
        this.namaProduk = namaProduk;
        this.hargaMakanan = hargaMakanan;
    }
    public String getNamaMerchant(){
        return this.namaMerchant;
    }
    public void setNamaMerchant(String namaMerchant){
        this.namaMerchant=namaMerchant;
    }
    public String getNamaProduk(){
        return this.namaProduk;
    }
    public void setNamaProduk(String namaProduk){
        this.namaProduk=namaProduk;
    }
    public Double getHargaMakanan(){
        return this.hargaMakanan;
    }
    public void setHargaMakanan(Double hargaMakanan){
        this.hargaMakanan=hargaMakanan;
    }
}
