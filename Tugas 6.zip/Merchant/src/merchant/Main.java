/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package merchant;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        Datamerchant.merch = Datamerchant.tambahMerchant(new Merchant("Bakso Pak Sahid", "Bakso", 8000.0));
        Datamerchant.merch = Datamerchant.tambahMerchant(new Merchant("Nasgor Mbledes", "Nasi Goreng Jawa", 10000.0));
        Datamerchant.merch = Datamerchant.tambahMerchant(new Merchant("Ayam Geprek Kak Ros", "Ayam Kota Ekstra Nasi", 10000.0));
        Datamerchant.merch = Datamerchant.tambahMerchant(new Merchant(in.nextLine(), in.nextLine(), in.nextDouble()));
        in.nextLine();
        Datamerchant.merch = Datamerchant.tambahMerchant(new Merchant(in.nextLine(), in.nextLine(), in.nextDouble()));
        in.nextLine();
        Datamerchant.merch = Datamerchant.tambahMerchant(new Merchant(in.nextLine(), in.nextLine(), in.nextDouble()));
        Datamerchant.tampilData();
    }
    
}
