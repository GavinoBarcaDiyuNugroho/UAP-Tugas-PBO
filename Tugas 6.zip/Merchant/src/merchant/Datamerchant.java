/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package merchant;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Datamerchant {
    static Scanner in = new Scanner(System.in);
    static Merchant merch[] = new Merchant[6];
    public static Merchant[] tambahMerchant(Merchant merchant){
        for(int a = 0; a<merch.length;a++){
            if(merch[a]==null){
                merch[a]=merchant;
                break;
            }
        }
        return merch;
    }
    public static void tampilData(){
        for(Merchant mch1 : merch){
            System.out.println("====Tampilan Data UB Food====");
            System.out.println("Nama Merchant   : "+mch1.getNamaMerchant());
            System.out.println("Nama Produk     : "+mch1.getNamaProduk());
            System.out.println("Nama Harga      : "+mch1.getHargaMakanan());
        }
    }
    public static Merchant carimerchant(String namaMerchant){
        int A = 0;
        for (int i = 0; i < merch.length; i++) {
            
            if(merch[i].getNamaMerchant()==namaMerchant){
                A = i;
                return merch[A];
            }
                break;
        }
        return null;
    }
    public static void tampilMerchant(Merchant merchant){
        merchant.getNamaMerchant();
    }
    public static void updateMerchant(Merchant merchant){
        merchant.setNamaMerchant(in.nextLine());
        merchant.setNamaProduk(in.nextLine());
        merchant.setHargaMakanan(in.nextDouble());
    }
}
