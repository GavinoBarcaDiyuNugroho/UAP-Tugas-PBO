/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author DELL
 */
public class Manajer extends Pekerja{
    private int lamaKerja;
    public Manajer(int Jam, int hari, String NIP, String name, String NIK, boolean kelamin, boolean menikah, int lamaKerja) {
        super(Jam, hari, NIP, name, NIK, kelamin, menikah);
        this.lamaKerja = lamaKerja;
    }
    public int getLamker(){
        return lamaKerja;
    }
    @Override
    public String toString(){
        String gender;
        double total;
        double plus = 0.3;
        total = (getPendapatan()+15)+getGaji()+getBonus();
        if(this.jeniskelamin){
            gender = "Laki-Laki";
        }
        else gender = "Perempuan";
        return "Nama            : " + getNama() + "\n" + 
               "NIK             : " + getNIK()+ "\n" + 
               "Jenis Kelamin   : " + gender + "\n" + 
               "Pendapatan      : " + "$"+total+"\n" +
               "Bonus           : " + "$"+(getBonus()+(int)(getBonus()*plus))+"\n" +
               "Gaji            : " +"$"+getGaji()+"\n" +
               "Status          : " + getStat()+"\n"+
               "Lama Kerja      : " + getLamker()+" hari";
    }
    
}
