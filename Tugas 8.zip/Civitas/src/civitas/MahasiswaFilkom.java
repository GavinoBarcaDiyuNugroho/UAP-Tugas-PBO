/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author DELL
 */
public class MahasiswaFilkom extends Manusia{
    private String NIM;
    private double IPK;

    public MahasiswaFilkom(String name, String NIK, boolean kelamin, boolean menikah, String NIM, double IPK) {
        super(name, NIK, kelamin, menikah);
        this.NIM = NIM;
        this.IPK = IPK;
    }
    
    public String getNIM(){
        return NIM;
    }
    public double getIPK(){
        return IPK;
    }
    public String getStat(){
        String prodi = "";
        String angkatan;
        angkatan = "20" + getNIM().substring(0, 2);
        int prod = Integer.parseInt(getNIM().substring(6, 7));
        switch (prod) {
            case 2:
                prodi = "Tehnik Meniup Gelembung";
                break;
            case 3:
                prodi = "Tehnik Berburu Ubur Ubur";
                break;
            case 4:
                prodi = "Sistem Perhamburgeran";
                break;
            case 6:
                prodi = "Pendidikan Chum Bucket";
                break;
            case 7:
                prodi = "Teknologi Telepon Kerang";
                break;
            default:
                break;
        }
        return prodi +", " + angkatan;
    }
    public double getBeasiswa(){
        double ip = getIPK();
        if(ip>3 && ip<=3.5){
            return 50.0;
        }
        else if (ip>3.5){
            return 75.0;
        }
        else return 0.0;
    }
    @Override
    public String toString(){
        String gender;
        double total = getPendapatan()+ getBeasiswa();
        if(this.jeniskelamin){
            gender = "Laki-Laki";
        }
        else gender = "Perempuan";
        return "Nama            : " + getNama() + "\n" + 
               "NIK             : " + getNIK()+ "\n" + 
               "Jenis Kelamin   : " + gender + "\n" + 
               "Pendapatan      : " + "$"+total+"\n" +
               "IPK             : " + getIPK()+"\n" +
               "NIM             : "+ getNIM()+"\n" +
               "Status          : "+getStat();
    }
    
    
}
