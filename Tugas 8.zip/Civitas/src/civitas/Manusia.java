/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author DELL
 */
public class Manusia {

    /**
     * @param args the command line arguments
     */
    private String name;
    private String nik;
    boolean jeniskelamin;
    boolean menikah;
    
    public void setKelamin(boolean kelamin){
        this.jeniskelamin = kelamin;
    }
    public boolean getKelamin(){
        return this.jeniskelamin;
    }
    public void setMenikah(boolean menikah){
        this.menikah = menikah;
    }
    public boolean getMenikah(){
        return this.menikah;
    }
    public void setNama(String nama){
        this.name = nama;
    }
    public String getNama(){
        return name;
    }
    public void setNIK(String nik){
        this.nik = nik;
    }
    public String getNIK(){
        return nik;
    }
    public Manusia(String name, String NIK, boolean kelamin, boolean menikah){
        setNama(name);
        setNIK(NIK);
        setKelamin(kelamin);
        setMenikah(menikah);
    }
    public double getTunjangan(){
        if (this.menikah == true){
            if (this.jeniskelamin == true){
                return 25.0;
            }
            else return 20.0;
        }
        else return 15.0;
    }
    public double getPendapatan(){
        return getTunjangan();
    }
    
    public String toString(){
        String gender;
        if(this.jeniskelamin){
            gender = "Laki-Laki";
        }
        else gender = "Perempuan";
        return "Nama            : " + getNama() + "\n" + 
               "NIK             : " + getNIK()+ "\n" + 
               "Jenis Kelamin   : " + gender + "\n" + 
               "Pendapatan      : " + "$"+getPendapatan();
    }
    
}
