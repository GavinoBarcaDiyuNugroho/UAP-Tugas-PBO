/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author DELL
 */
public class Pekerja extends Manusia{
    private String NIP;
    private int Jam;
    private int Hari;
    private double gaji;
    private double bonus;

    public Pekerja(int Jam, int hari, String NIP,String name, String NIK, boolean kelamin, boolean menikah) {
        super(name, NIK, kelamin, menikah);
        this.NIP = NIP;
        this.Jam = Jam;
        this.Hari = hari;
    }
    public String getNIP(){
        return NIP;
    }
    public int getJam(){
        return Jam;
    }
    public int getHari(){
        return Hari;
    }
    public double getGaji(){
        this.gaji = this.Hari * this.Jam * 15;
        return gaji;
    }
    public double getBonus(){
        double libur;
        double lembur=0;
        int h = getHari()/7;
        libur = h*2*getJam()*20;
        if(getJam()>7){
            int j = getJam() - 7 ;
            lembur = (getHari()-(h*2))*j*7;
        }
        this.bonus = libur + lembur;
        return bonus;
        
    }
    public String getStat(){
        String kantor = "";
        String departemen ="";
        String Cabang;
        int prod = Integer.parseInt(getNIP().substring(6, 7));
        switch (prod) {
            case 1:
                departemen = "Pemasaran";
                break;
            case 2:
                departemen = "Humas";
                break;
            case 3:
                departemen = "Riset";
                break;
            case 4:
                departemen = "Teknologi";
                break;
            case 5:
                departemen = "Personalia";
                break;
            case 6:
                departemen = "Akademik";
                break;
            case 7:
                departemen = "Administrasi";
                break;
            case 8:
                departemen = "Operasional";
                break;
            case 9:
                departemen = "Pembangunan";
                break;
            default:
                break;
        }
        prod = Integer.parseInt(getNIP().substring(0, 1));
        switch (prod) {
            case 1:
                kantor = "Monstadt";
                break;
            case 2:
                kantor = "Liyue";
                break;
            case 3:
                kantor = "Inazuma";
                break;
            case 4:
                kantor = "Sumeru";
                break;
            case 5:
                kantor = "Fontaine";
                break;
            case 6:
                kantor = "Natlan";
                break;
            case 7:
                kantor = "Snezhnaya";
                break;
            default:
                break;
        }
        Cabang = getNIP().substring(2, 3);
        return departemen +", "+ kantor + " cabang ke-"+Cabang ;
    }
    @Override
    public String toString(){
        String gender;
        double total;
        total = getPendapatan()+getGaji()+getBonus();
        if(this.jeniskelamin){
            gender = "Laki-Laki";
        }
        else gender = "Perempuan";
        return "Nama            : " + getNama() + "\n" + 
               "NIK             : " + getNIK()+ "\n" + 
               "Jenis Kelamin   : " + gender + "\n" + 
               "Pendapatan      : " + "$"+total+"\n" +
               "Bonus           : " + "$"+getBonus()+"\n" +
               "Gaji            : " +"$"+getGaji()+"\n" +
               "Status          : " + getStat();
    }
    
    
}
