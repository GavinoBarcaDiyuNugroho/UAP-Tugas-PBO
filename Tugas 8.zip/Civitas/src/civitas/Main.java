/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author DELL
 */
public class Main {
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("================================================");
        Manusia man1 = new Manusia ("Avan","3923842934",true,true);
        System.out.println(man1.toString());
        System.out.println("================================================");
        MahasiswaFilkom mhs = new MahasiswaFilkom("Gavino Barca Diyu Nugroho","31564895",true,false,"215150607111018", 3.89);
        System.out.println(mhs.toString());
        System.out.println("================================================");
        Pekerja pkj = new Pekerja(7, 22, "195102439283", "Iqbal Biondy", "351717969", true, true);
        System.out.println(pkj.toString());
        System.out.println("================================================");
        Manajer manajer1 = new Manajer(9, 20,"204837283728", "LyraHertin", "351707384392",false, false, 1500);
        System.out.println(manajer1.toString());
        System.out.println("================================================");
        Manusia man2 = new Manusia("Jono", "26052111015", true, false);
        System.out.println(man2.toString());
        System.out.println("================================================");
        Manusia man3 = new Manusia("Reni", "2022391182", false, true);
        System.out.println(man3.toString());
        System.out.println("================================================");
        MahasiswaFilkom mhs1 = new MahasiswaFilkom("Adnan", "562100015", true, false, "205150401111118", 3.1);
        System.out.println(mhs1.toString());
        System.out.println("================================================");
        MahasiswaFilkom mhs2 = new MahasiswaFilkom("Akbar", "2001152020005", true, false, "195150201111025", 3.4);
        System.out.println(mhs2.toString());
        System.out.println("================================================");
        Pekerja pkj1 = new Pekerja(5, 19, "2246184111", "Trisari Ratna Dwi", "1986520001156", false, true);
        System.out.println(pkj1.toString());
        System.out.println("================================================");
        Pekerja pkj2 = new Pekerja(10, 23, "5216182001", "Bagus Ramadhan Adiansyah", "6986520001156", true, false);
        System.out.println(pkj2.toString());
        System.out.println("================================================");
        Manajer manajer2 = new Manajer (7, 12, "612249411102", "Randi Pros", "190202050600014", true, true, 2000);
        System.out.println(manajer2.toString());
        System.out.println("================================================");
        Manajer manajer3 = new Manajer (4, 20, "419501550560", "Rian Megaplex", "199802523020156", true, false, 1000);
        System.out.println(manajer3.toString());
        System.out.println("================================================");
    }
    
}
