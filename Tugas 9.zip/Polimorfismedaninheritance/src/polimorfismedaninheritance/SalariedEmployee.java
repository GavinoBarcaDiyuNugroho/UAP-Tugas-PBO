/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismedaninheritance;

/**
 *
 * @author DELL
 */
public class SalariedEmployee extends Employee {
    private double weeklysalary;
    public SalariedEmployee(String firstname, String lastname, String socialsecuritynumber, int Birthday, int Birthmonth, int Birthyear, double weeklysalary) {
        super(firstname, lastname, socialsecuritynumber, Birthday, Birthmonth, Birthyear);
        if(weeklysalary<0.0){
            throw new IllegalArgumentException("Weekly salary must be >= 0.0");
        }
        this.weeklysalary = weeklysalary;
    }
    public void setWeeklySalary(double weeklysalary){
        if(weeklysalary<0.0){
            throw new IllegalArgumentException("Weekly salary must be >= 0.0");
        }
        this.weeklysalary = weeklysalary;
    }
    public double getWeeklySalary(){
        return this.weeklysalary;
    }
    @Override
    public double earnings(){
        return getWeeklySalary();
    }
    @Override
    public String toString(){
        return String.format("salaried employee: %s%n%s: $%,.2f",super.toString(), "weekly salary", getWeeklySalary());
    }
}
