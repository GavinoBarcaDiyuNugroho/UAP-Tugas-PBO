/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismedaninheritance;

/**
 *
 * @author DELL
 */
public class Pieceworker extends Employee{
    //10.14
    private double wage;
    private double pieces;
    public Pieceworker( String firstname, String lastname, String socialsecuritynumber, int Birthday, int Birthmonth,int Birthyear, double wage, double pieces){
        super(firstname, lastname, socialsecuritynumber, Birthday, Birthmonth, Birthyear);
        if(wage<0.0){
            throw new IllegalArgumentException("Wage must be >= 0.0");
        }
        if(pieces<0.0){
            throw new IllegalArgumentException("Pieces must be >= 0.0");
        }
        this.wage = wage;
        this.pieces = pieces;
    }
    public void setWage(double wage){
        if(wage<0.0){
            throw new IllegalArgumentException("Wage must be >= 0.0");
        }
        this.wage = wage;
    }
    public double getWage(){
        return this.wage;		
    }
    public void setPieces(double pieces){
        if(pieces<0.0){
            throw new IllegalArgumentException("Pieces must be >= 0.0");
        }
        this.pieces = pieces;     
    }
    public double getPieces(){
        return this.pieces;
    }
    public double earnings(){
        double pay;
        pay = getPieces() * getWage();
        return pay;
    }
    @Override 
    public String toString(){
        return String.format("Piece Worker: " + super.toString() + " Weekly pay " + earnings());
    }
    
}
