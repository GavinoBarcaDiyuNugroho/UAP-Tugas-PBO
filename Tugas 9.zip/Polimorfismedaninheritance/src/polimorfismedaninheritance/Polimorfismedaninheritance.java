/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismedaninheritance;

/**
 *
 * @author DELL
 */
public class Polimorfismedaninheritance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Date tanggal = new Date(10,5,2022);
        Employee pegawai1 = new SalariedEmployee("Ocit", "Bagus", "0021651120",24,03,2002, 700.00);
	Employee pegawai2 = new HourlyEmployee("Kurma", "Sari", "0011512065",10,22,1998, 20.50, 20);
	Employee pegawai3 = new CommissionEmployee("Agung", "Darmono", "2170025341",5,6,1985, 2500, 0.66);
	CommissionEmployee pegawai4 = new BasePlusCommissionEmployee( "Danang", "Mahendra", "1055120235",14,01,1999, 5400, 0.5, 350); 
	Pieceworker pegawai5= new Pieceworker ("Putra", "Azkia", "2001506026", 12, 5, 1997, 25, 110);
       //Implementasi polimorfisme
        Employee[] arr = new Employee[5];
        arr[0] = pegawai1;
        arr[1] = pegawai2;
        arr[2] = pegawai3;
        arr[3] = pegawai4;
        arr[4] = pegawai5;
        
        //10.12
        for(int a = 0;a<5;a++){
            if (arr[a].getBirthmonth() == tanggal.getMonth()){
                System.out.println(arr[a] + " earned " + (arr[a].earnings() + 100) + " Birthday Bonus!"+"\n");
            }
            
            else System.out.println(arr[a] + " earned " + arr[a].earnings()+"\n");
        }
        
        
    }
    
}
