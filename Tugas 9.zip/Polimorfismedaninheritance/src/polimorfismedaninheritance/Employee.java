/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismedaninheritance;

/**
 *
 * @author DELL
 */
public abstract class Employee {
    private final String firstname;
    private final String lastname;
    private final String socialsecuritynumber;
    private final int Birthmonth;
    private final int Birthday;
    private final int Birthyear;
    public Employee(String firstname, String lastname, String socialsecuritynumber, int Birthday, int Birthmonth, int Birthyear){
        this.firstname = firstname;
        this.lastname = lastname;
        this.socialsecuritynumber = socialsecuritynumber;
        this.Birthday = Birthday;
        this.Birthmonth = Birthmonth;
        this.Birthyear = Birthyear;
    }
    public String getFirstName(){
        return firstname;
    }
    public String getLastName(){
        return lastname;
    }
    public String getsocialsecuritynumber(){
        return socialsecuritynumber;
    }
    public int getBirthmonth(){
        return Birthmonth;
    }
    
    @Override
    public String toString(){
        return String.format("%s %s%nsocial security number: %s",getFirstName(), getLastName(), getsocialsecuritynumber());
    }
    public abstract double earnings();
}
